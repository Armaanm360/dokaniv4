 
 <?php $__env->startSection('content'); ?>
<div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
 <div class="container-fluid">
  <div class="row g-3">
   <div class="col-12">
    <div class="card">
     <div class="card-body">
      <div class="input-group">
       <input type="text" class="form-control" placeholder="Search...">
       <button class="btn btn-secondary" type="button">Search</button>
       
       <a class="btn btn-primary" href="<?php echo e(url('company-info/create')); ?>" type="button">Add Company</a>
      </div>
      <!-- Modal: Add new Customers -->
      <!-- <button class="btn btn-primary px-4 text-uppercase" data-bs-toggle="modal" data-bs-target="#add_customers" type="button">Add new Customers</button> -->
      
     </div>
    </div>
   </div>
   <div class="col-12">
    <table id="myDataTable_no_filter" class="table myDataTable align-middle custom-table">
     <thead>
      <tr>
       <th>#</th>
       <th>Company Name</th>
       <th>Mobile</th>
       <th>Email</th>
       <th>Address</th>
       <th>Action</th>
      </tr>
     </thead>
     <tbody>
        <?php $__currentLoopData = $company_info_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->index+1); ?></td>
            <td>
                 <?php echo e($data->company_name); ?>

            </td>
            <td><?php echo e($data->company_phone); ?></td>
            <td><?php echo e($data->company_email); ?></td>
            <td>
                <?php echo e($data->company_address); ?>

            </td>
            <td>
             <a type="button" href="<?php echo e(route('company-info.edit', $data->company_id)); ?>" class="btn btn-link btn-sm text-primary" data-bs-toggle="tooltip" data-bs-placement="top"
              title="Edit"><i class="fa fa-gear"></i></a>
              <a type="button"  class="btn btn-link btn-sm text-danger" data-bs-toggle="tooltip" data-bs-placement="top"
              title="Delete" onclick="deleteNow(<?php echo e($data->company_id); ?>)"><i class="fa fa-trash"></i></a>
            </td>
           </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </tbody>
    </table>
   </div>
  </div> <!-- .row end -->
 </div>
</div>
<script type="text/javascript">
        function deleteNow(params) {
            var isConfirm = confirm('Are You Sure!');
    if (isConfirm) {          
                    $('.loader').show();
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: 'DELETE',
                        url: "company-info" + '/' + params,
                        success: function(data) {
                            location.reload();
                        }
                    }).done(function() {
                        $("#success_msg").html("Data Save Successfully");
                    }).fail(function(data, textStatus, jqXHR) {
                        $('.loader').hide();
                        var json_data = JSON.parse(data.responseText);
                        $.each(json_data.errors, function(key, value) {
                            $("#" + key).after(
                                "<span class='error_msg' style='color: red;font-weigh: 600'>" +
                                value +
                                "</span>");
                        });
                    });
    } else {
        $('.loader').hide();
    }
        }



 
</script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/settings/company_info/list_company_info.blade.php ENDPATH**/ ?>