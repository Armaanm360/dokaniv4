<!-- Form section -->
<!-- start: page toolbar -->
<div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
    <div class="container-fluid">
        <div class="row g-3">
            <div class="col-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h3> Datewise Purchase Report</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Purchase Date</th>
                                    <th>Purchase Number</th>
                                    <th>Supplier</th>
                                    <th>Total</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datewise_purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $supplier = "";
                                    $supplierdata = App\Models\Supplier\Supplier::supplier($purchase->purchase_supplier_id);
                                    if($supplierdata)
                                    {
                                        $supplier = $supplierdata->supplier_name;
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($purchase->purchase_date); ?></td>
                                        <td><?php echo e($purchase->purchase_number); ?></td>
                                        <td><?php echo e($supplier); ?></td>
                                        <td><?php echo e($purchase->purchase_quantity); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>&nbsp</td>
                                    <td>&nbsp</td>
                                    <td>&nbsp</td>
                                    <td>Total:</td>
                                    <td><?php echo e($totalpurchases); ?></td>
                                </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- start: page body -->

<!-- end form section -->



<?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/report/purchase/date_wise_purchase_report.blade.php ENDPATH**/ ?>