
<?php $__env->startSection('content'); ?>
    <!-- start: page toolbar -->
    <div class="page-toolbar px-xl-4 px-sm-2 px-0 py-3">
        <div class="container-fluid">
            <div class="row g-3 mb-3 align-items-center">
                <div class="col">
                    <ol class="breadcrumb bg-transparent mb-0">
                        <li class="breadcrumb-item"><a class="text-secondary" href="<?php echo e(url('')); ?>}">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item"><a class="text-secondary" href="<?php echo e(url('invoice')); ?>">Invoice</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Create Invoice</li>
                    </ol>
                </div>
            </div> <!-- .row end -->
            
        </div>
    </div>
    <!-- start: page body -->
    <form class="row maskking-form" id="add_form">
        <?php echo csrf_field(); ?>
        <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
            <div class="container-fluid">
                <!-- Create invoice -->
                <div class="row g-3">
                    <div class="col-12">





                        <div class="card">
                            <div class="card-header">
                                <h6 class="card-title mb-0">BASIC INFORMATION</h6>
                            </div>
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-lg-3 col-sm-12">
                                        <span class="float-label">
                                            <label for="exampleFormControlSelect1">Customer Type</label>
                                            <select class="form-control form-control-lg" id="customer_type"
                                                name="customer_type">
                                                <option disabled selected>Select Customer Type</option>
                                                <option value="online">Online</option>
                                                <option value="offline">Offline</option>
                                            </select>
                                        </span>
                                        <input type="hidden" id="hiddenAccId" name="expense_account">
                                    </div>
                                    <div class="col-lg-3 col-sm-12">
                                        <span class="float-label">
                                            <label for="warehouse">Client</label>
                                            <input type="text" class="form-control form-control-lg" id="client"
                                                placeholder="Select Customer/Client" name="client">
                                        </span>
                                        <input type="hidden" id="hidden_client_id" name="hidden_client_id" value="">
                                    </div>
                                    
                                    <div class="col-lg-3 col-sm-12">
                                        <span class="float-label">
                                            <label for="warehouse">Branch</label>
                                            <input type="text" class="form-control form-control-lg" id="branchName"
                                                placeholder="branch" name="branch_id">

                                            <input type="hidden" class="form-control form-control-lg" id="hidden_branch_id"
                                                placeholder="Brnach" name="hidden_brnach_id" value=""> </span>
                                    </div>
                                    
                                    <div class="col-lg-3 col-sm-12">
                                        <span class="float-label">
                                            <label for="warehouse">Staff</label>
                                            <input type="text" class="form-control form-control-lg" id="staff"
                                                placeholder="Select Staff" name="staff">
                                        </span>
                                        <input type="hidden" id="hidden_staff_id" name="hidden_staff_id" value="">
                                    </div>

                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-lg-3 col-sm-12">
                                        <span class="float-label">
                                            <label for="warehouse">Invoice No</label>
                                            <input type="text" class="form-control form-control-lg" id="invoice_no"
                                                placeholder="Invoice No" name="invoice_no" value="" readonly>
                                        </span>
                                    </div>
                                    <div class="col-lg-3 col-sm-12">
                                        <span class="float-label">
                                            <label for="warehouse">Invoice Date</label>
                                            <input type="text" class="form-control form-control-lg" id="invoice_no"
                                                placeholder="Invoice No" name="invoice_no" value="" readonly>
                                        </span>
                                    </div>
                                    <div class="col-lg-3 col-sm-12">
                                        <span class="float-label">
                                            <label for="warehouse">Sales Date</label>
                                            <input type="text" class="form-control form-control-lg" id="invoice_no"
                                                placeholder="Invoice No" name="invoice_no" value="" readonly>
                                        </span>
                                    </div>
                                    
                                </div>

                                


                            </div>


                        </div>
                    </div>
                    <br>
                    <div class="card print_invoice">
                        <div class="card-body">
                            <div class="card p-3">
                                <div style="clear:both"></div>
                                <table class="items">
                                    <tbody>
                                        <tr>
                                            <th>Sl</th>
                                            <th>Item Details</th>
                                            <th>Stock</th>
                                            <th>Qty</th>
                                            <th>Unit</th>
                                            <th>Unit Price</th>
                                            <th>Total Unit Price</th>
                                            <th>Discount(%)</th>
                                            <th>Total Price</th>
                                            <th>#</th>
                                        </tr>
                                        <div id="billingDetailsList">
                                            
                                        </div>
                                    </tbody>
                                </table>

                                <table>
                                    <tbody>
                                        <tr id="hiderow">
                                            
                                        </tr>
                                        <tr>

                                            <td colspan="10" width="80%"
                                                class="total-line text-right invoice-subtotal"
                                                style="text-align: right;border:0">Subtotal</td>
                                            <td class="total-value">

                                                <input type="number" name="invoice_subtotal" id="invoiceSubTotal"
                                                    value="" readonly>
                                            </td>
                                        </tr>
                                        <tr>

                                            <td colspan="10" class="total-line" style="text-align: right;border:0">
                                                Product Discount</td>
                                            <td class="total-value">
                                                <input type="number" name="product_discount" id="productDiscount"
                                                    value="" readonly>
                                            </td>
                                        </tr>
                                        <tr>

                                            <td colspan="10" class="total-line" style="text-align: right;border:0">
                                                Vat Rate(%)</td>
                                            <td class="total-value">
                                                <input type="number" name="vat_rate" id="vat_rate" value="7.50"
                                                    readonly>
                                            </td>
                                        </tr>
                                        <tr>

                                            <td colspan="10" class="total-line" style="text-align: right;border:0">
                                                Vat Amount(%)</td>
                                            <td class="total-value">
                                                <input type="number" name="vat_amount" id="vat_amount" value=""
                                                    readonly>
                                            </td>
                                        </tr>

                                        <tr>

                                            <td colspan="10" class="total-line" style="text-align: right;border:0">
                                                Overall Discount</td>
                                            <td class="total-value">
                                                <input type="number" name="overall_discount" id="overall_discount"
                                                    value="">
                                            </td>
                                        </tr>
                                        <tr>

                                            <td colspan="10" class="total-line" style="text-align: right;border:0">
                                                Grand Total</td>
                                            <td class="total-value">
                                                <input type="number" name="grand_total" id="grand_total" value=""
                                                    readonly>
                                            </td>
                                        </tr>
                                        <tr>

                                            <td colspan="10" class="total-line" style="text-align: right;border:0">
                                                Payment Type</td>
                                            <td class="total-value">
                                                <span class="float-label">
                                                    <select class="form-control form-control-lg" id="payment_type"
                                                        name="payment_type">
                                                        <option selected disabled>Select Payment Type</option>

                                                        <option value="BANK">BANK</option>
                                                        <option value="CASH">CASH</option>
                                                        <option value="MOBILE_BANKING">MOBILE_BANKING</option>
                                                    </select>
                                                </span>
                                                <input type="hidden" id="hiddenAccId" name="expense_account">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="10" class="total-line" style="text-align: right;border:0">
                                                Account</td>
                                            <td class="total-value">
                                                <span class="float-label">
                                                    <select class="form-control form-control-lg" id="getAccount"
                                                        name="account">

                                                    </select>
                                                </span>
                                                <input type="hidden" id="hiddenAccId" name="expense_account">
                                            </td>
                                        </tr>


                                        <tr>

                                            <td colspan="10" class="total-line" style="text-align: right;border:0">
                                                Total Paying</td>
                                            <td class="total-value">
                                                <input type="number" name="paid_amount" id="paid_amount"
                                                    value="">
                                            </td>
                                        </tr>
                                        <tr>

                                            <td colspan="10" class="total-line balance"
                                                style="text-align: right;border:0" id="changed_text_due">Change</td>
                                            <td class="total-value balance">
                                                <div class="due">
                                                    <input class="invoice-due" type="number" name="changed_amount"
                                                        id="changed_amount" value="" readonly>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>



                <div class="col-12 text-center text-md-end" id="InvoiceButtonArea">
                    <button type="submit" class="btn btn-lg btn-primary"><i
                            class="fa fa-print me-2"></i>Payment</button>
                    <button type="button" class="btn btn-lg btn-secondary"><i class="fa fa-envelope me-2"></i>Send
                        PDF</button>
                </div>

                <div class="col-12 text-center text-md-end" id="InvoiceSkipButtonArea" style="display: none">
                    
                </div>







    </form>

    <div id='checkMoneyReceipt'></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/invoice/return_invoice.blade.php ENDPATH**/ ?>