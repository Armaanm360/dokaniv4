
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h3> Today Pos Sales</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Invoice No</th>
                                    <th>Staff</th>
                                    <th>Client Phone</th>
                                    <th>By Sale</th>
                                    <th>Sales Date</th>
                                    <th>Net Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($invoice->invoice_no); ?></td>
                                        <td><?php echo e($invoice->staff_name); ?></td>
                                        <td><?php echo e($invoice->client_phone_number); ?></td>
                                        <td>Bank</td>
                                        <td><?php echo e($invoice->sales_date); ?></td>
                                        <td><?php echo e($invoice->grand_total); ?></td>
                                        <td>
                                            <a href="<?php echo e('invoice/' . $invoice->sale_id . '/' . 'edit'); ?>"
                                                class="btn btn-sm btn-primary">Edit</a>
                                            
                                            <a href="<?php echo e('invoice/' . $invoice->sale_id); ?>"
                                                class="btn btn-sm btn-info">View</a>

                                            <a href="<?php echo e('invoice-return-sale/' . $invoice->sale_id); ?>"
                                                class="btn btn-sm btn-danger">Return</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/invoice/today_list_invoice.blade.php ENDPATH**/ ?>