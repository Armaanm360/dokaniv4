
<?php $__env->startSection('content'); ?>
    <?php $warehouse = app('App\Models\Warehouse\Warehouse'); ?>
    <?php $quantity = app('App\Models\PosTransfer\PosTransfer'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h3> All Transfers</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Transfer No</th>
                                    <th>Transfer Date</th>
                                    <th>From Warehouse</th>
                                    <th>To Warehouse</th>
                                    <th>Total Qty</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transfer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($transfer->transferNo); ?></td>
                                        <td><?php echo e($transfer->transferDate); ?></td>
                                        <td><?php echo e($warehouse->getWareHouseName($transfer->fromWarehouseID)); ?></td>
                                        <td><?php echo e($warehouse->getWareHouseName($transfer->toWarehouseID)); ?></td>
                                        <td><?php echo e($quantity->getTotalProductQuantity($transfer->transferNo)); ?></td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#myTable')
                .dataTable();


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/transfer/list_transfer.blade.php ENDPATH**/ ?>