<!-- Form section -->
<!-- start: page toolbar -->
<div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
    <div class="container-fluid">
        <div class="row g-3">
            <div class="col-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h3> Datewise Transfer Report -Warehouse to Warehouse (OUT)</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Date</th>
                                    <th>Transfer No</th>
                                    <th>To</th>
                                    <th>Total Quanitity</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $warehouse_to_warehouse_out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse_out): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $to_ware_house = "";
                                    $total_quantity = "";
                                    $to_ware_house_name = App\Models\Warehouse\Warehouse::warehouseName($warehouse_out->toWarehouseID);
                                    if($to_ware_house_name)
                                    {
                                        $to_ware_house = $to_ware_house_name->warehouse_name;
                                    }
                                    $totalQuantity = App\Models\PosTransferProduct\PosTransferProduct::quantity($warehouse_out->transferNo);
                                    if($totalQuantity)
                                    {
                                        $total_quantity = $totalQuantity;
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($warehouse_out->transferDate); ?></td>
                                        <td><?php echo e($warehouse_out->transferNo); ?></td>
                                        <td><?php echo e($to_ware_house); ?></td>
                                        <td><?php echo e($total_quantity); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h3> Datewise Transfer Report -Warehouse to Warehouse (IN)</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Date</th>
                                    <th>Transfer No</th>
                                    <th>From</th>
                                    <th>Total Quanitity</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $warehouse_to_warehouse_in; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse_in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $from_ware_house = "";
                                    $total_quantity = "";
                                    $from_ware_house_name = App\Models\Warehouse\Warehouse::warehouseName($warehouse_in->fromWarehouseID);
                                    if($from_ware_house_name)
                                    {
                                        $from_ware_house = $from_ware_house_name->warehouse_name;
                                    }
                                    $totalQuantity = App\Models\PosTransferProduct\PosTransferProduct::quantity($warehouse_in->transferNo);
                                    if($totalQuantity)
                                    {
                                        $total_quantity = $totalQuantity;
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($warehouse_in->transferDate); ?></td>
                                        <td><?php echo e($warehouse_in->transferNo); ?></td>
                                        <td><?php echo e($from_ware_house); ?></td>
                                        <td><?php echo e($total_quantity); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h3> Datewise Transfer Report -Warehouse to Branch</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Date</th>
                                    <th>Transfer No</th>
                                    <th>To (Branch)</th>
                                    <th>Total Quanitity</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $warehouse_to_branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse_to_branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $branchName = "";
                                    $total_quantity = "";
                                    $to_branch_name = App\Models\Branch\Branch::branchName($warehouse_to_branch->branch_id);
                                    if($to_branch_name)
                                    {
                                        $branchName = $to_branch_name->branch_name;
                                    }
                                    $totalQuantity = App\Models\Transfer\WarehouseToBranchItems::quantity($warehouse_to_branch->warehouse_to_branch_transfer_number);
                                    if($totalQuantity)
                                    {
                                        $total_quantity = $totalQuantity;
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($warehouse_to_branch->transfer_date); ?></td>
                                        <td><?php echo e($warehouse_to_branch->warehouse_to_branch_transfer_number); ?></td>
                                        <td><?php echo e($branchName); ?></td>
                                        <td><?php echo e($total_quantity); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- start: page body -->

<!-- end form section -->



<?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/report/datewisetransfer/get_transfer_report.blade.php ENDPATH**/ ?>