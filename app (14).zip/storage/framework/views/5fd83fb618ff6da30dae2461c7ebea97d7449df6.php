
<?php $__env->startSection('content'); ?>

<div class="content">

    <div class="page-inner">
 
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('List of Permission')); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatable" class="display table table-striped table-hover" >
                                <thead>

                                    <tr>
                                        <th><?php echo e(__('Sl')); ?></th>
                                        <th><?php echo e(__('Section')); ?></th>
                                        <th><?php echo e(__('Name')); ?></th>
                                        <th><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $all_permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($loop->iteration); ?>

                                        </td>

                                        <td>
                                            <?php echo e($row->section_name); ?>

                                        </td>

                                        <td>
                                            <?php echo e($row->name); ?>

                                        </td>

                                        <td>
                                            <a href="<?php echo e(url('permissions')); ?>/<?php echo e($row->id); ?>/edit" class="btn btn-success btn-sm">
                                            <?php echo e(__('Edit')); ?>

                                            </a>
                                            <form  action="<?php echo e(route('permissions.destroy', $row->id)); ?>" method='POST' style='display: inline-block;'>
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                            <button onclick="return confirm('Are you want to delete this!')" class='btn btn-danger btn-sm' type='submit'><?php echo e(__('Delete')); ?></button>
                        </form>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th><?php echo e(__('Sl')); ?></th>
                                        <th><?php echo e(__('Section')); ?></th>
                                        <th><?php echo e(__('Name')); ?></th>
                                        <th><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </tfoot>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $('#basic-datatable').DataTable({ });

    });
</script>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/admin/pages/permission/list_permission.blade.php ENDPATH**/ ?>