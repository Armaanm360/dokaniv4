<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layouts.admin.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="layout-1" data-luno="theme-blue">
  <!-- start: sidebar -->
<?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- start: body area -->
  <div class="wrapper">
    <!-- start: page header -->
    <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- start: page toolbar -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- start: page footer -->
    <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Jquery Page Js -->
<?php echo $__env->make('layouts.admin.footerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/home.blade.php ENDPATH**/ ?>