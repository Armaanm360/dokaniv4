<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layouts.admin.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php
$company = \Illuminate\Support\Facades\DB::table('company_infos')->first();
$staff = \Illuminate\Support\Facades\DB::table('staff')
    ->where('staff_id', $pos[0]->staff_id)
    ->first();

//print_r($pos_sale);

?>

<div class="container-fluid">
    <div class="row">
        <div class="col-4"></div>
        <div class="col-4">
            <div id="printableArea">
                <div class="logo text-center">
                    <br>
                    <img src="<?php echo e(asset('public/assets/logo.png')); ?>" alt="Your Company Logo">
                    <p><?php echo e($company->company_address); ?></p>
                </div>
                <br>
                <h2 class="text-center text-danger">Invoice Return</h2>
                <div class="info text-center">
                    <h4><?php echo e($company->company_name); ?></h4>
                    <b>Cell: <?php echo e($company->company_phone); ?></b>
                    <p><b>BIN: 002256834-0201 Mushak-2.3</b></p>
                    <pre>Invoice: <?php echo e($pos[0]->invoice_no); ?></pre>
                </div>
                <div class="row">
                    <div class="col-6">
                        
                    </div>
                    <div class="col-6"></div>
                </div>
                <br>
                <div class="row">
                    <table class="table table-striped table-condensed content_table">

                        <tbody>
                            <tr>
                                <th width="5%">SL</th>
                                <!--<th width="15%">PO</th>-->
                                <th width="20%">Product</th>
                                <!--<th width="20%">Color</th>-->
                                <!--<th width="20%">Size</th>-->
                                <th width="14%">Price</th>
                                <th width="14%">Discount(%)</th>
                                <th width="10%">Return Quantity</th>
                                <th width="14%">Subtotal</th>
                            </tr>

                            <?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="item-row">
                                    <td class="item-name">

                                        <?php echo e($loop->index + 1); ?>


                                    </td>
                                    <td class="description">
                                        <?php echo e($pos->product_name); ?>

                                    <td>
                                        <?php echo e($pos->price); ?>

                                    </td>
                                    <td>
                                        <?php echo e($pos->discount_amount); ?>

                                    </td>
                                    <td><span class="price"><?php echo e($pos->return_quantity); ?></span></td>
                                    <td><span class="price"><?php echo e($pos->subTotal); ?></span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr> -->
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td class="text-right"><b>Return Charge</b></td>
                                <td class="text-right"><b><?php echo e($pos->return_quantity); ?></b></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td class="text-right"><b>Vat </b></td>
                                <td class="text-right"><b><?php echo e($pos->vat_amount); ?></b></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td class="text-right"><b>Return Amount</b></td>
                                <td class="text-right"><b><?php echo e($pos->return_amount); ?></b></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td class="text-right"><b>Discount</b></td>
                                <td class="text-right"><b><?php echo e($pos->product_discount); ?></b></td>
                            </tr>



                        </tbody>
                    </table>
                    
                </div>
                <div class="order_barcodes text-center">
                    <span style="font-size:9px;"> <b>Software Developed By M360 ICT</b></span>
                </div>
            </div>
            <div class="row">
                <button class="btn btn-larage btn-info mb-2" onclick="printDiv('printableArea')">Print</button>

                <a class="btn btn-larage btn-primary mb-2" href="<?php echo e(url('invoice-return')); ?>">Back to Pos</a>
            </div>



        </div>
        <div class="col-4"></div>
    </div>
</div>

<script>
    function printDiv(elementId) {
        var divContents = document.getElementById(elementId).innerHTML;
        var a = window.open('', '', 'height=1200, width=1200');
        a.document.write('<html>');
        a.document.write(divContents);
        a.document.write('</body></html>');
        a.document.close();
        a.print();
    }
</script>
<!-- Jquery Page Js -->
<?php echo $__env->make('layouts.admin.footerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/invoice_return/show_invoice.blade.php ENDPATH**/ ?>