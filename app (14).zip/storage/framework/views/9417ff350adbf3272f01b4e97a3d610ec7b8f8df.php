<!-- Form section -->
<!-- start: page toolbar -->
<div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
    <div class="container-fluid">
        <div class="row g-3">
            <div class="col-6 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h3>Purchase History</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Purchase Date</th>
                                    <th>Grandtotal</th>
                                    <th>Discount</th>
                                    <th>Nettotal</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $supplier_purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($purchase->purchase_date); ?></td>
                                        <td><?php echo e($purchase->purchase_subtotal); ?></td>
                                        <td><?php echo e($purchase->purchase_discount); ?></td>
                                        <td><?php echo e($purchase->purchase_net_total); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>
                                    <td>Total</td>
                                    <td><?php echo e($subtotal); ?></td>
                                    <td><?php echo e($discount); ?></td>
                                    <td><?php echo e($nettotal); ?></td>
                                </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-6 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h3> Payment History</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Date</th>
                                    
                                    <th>Payment</th>
                                    <th>Note</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $supplier_payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($payment->supplier_transaction_date); ?></td>
                                        
                                        
                                        <td><?php echo e($payment->supplier_transaction_amount); ?></td>
                                        <td><?php echo e($payment->supplier_transaction_note); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>
                                    <td>Total</td>
                                    <td><?php echo e($supplier_payment_total); ?></td>
                                    <td></td>
                                </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- start: page body -->

<!-- end form section -->



<?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/report/supplier_ledger/get_supplier_ledger_report.blade.php ENDPATH**/ ?>