<!-- Form section -->
<!-- start: page toolbar -->
<div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
    <div class="container-fluid">
        <div class="row g-3">
            <div class="col-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h3> Client Ledger Datewise Report</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Branch</th>
                                    <th>Date</th>
                                    <th>Debit</th>
                                    <th>Discount</th>
                                    <th>Return</th>
                                    <th>Credit</th>
                                    <th>Balance</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $client_ledger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ledger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $ledger_discount = "";
                                    $ledger_return = "";
                                    $branch_data = "";
                                    $discount = App\Models\Invoice\InvoicePosSale::discount($ledger->client_ledger_invoice_id);
                                    if($discount)
                                    {
                                        $ledger_discount = $discount;
                                    }
                                    $return = App\Models\Invoice\InvoicePosSale::return($ledger->client_ledger_invoice_id);
                                    if($return)
                                    {
                                        $ledger_return = $return;
                                    }

                                    $branch = App\Models\Invoice\InvoicePosSale::branch($ledger->client_ledger_invoice_id);
                                    if($branch)
                                    {
                                        $branch_data = $return->branch_name;
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($branch_data); ?></td>
                                        <td><?php echo e($ledger->client_ledger_date); ?></td>
                                        <td><?php echo e($ledger->client_ledger_dr); ?></td>
                                        <td><?php echo e($discount); ?></td>
                                        <td><?php echo e($ledger_return); ?></td>
                                        <td><?php echo e($ledger->client_ledger_cr); ?></td>
                                        <td><?php echo e($ledger->client_ledger_last_balance); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- start: page body -->

<!-- end form section -->



<?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/report/clientledger/get_client_ledger_report.blade.php ENDPATH**/ ?>